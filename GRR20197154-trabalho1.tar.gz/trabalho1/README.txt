Olá professor!
Na hora da divisão ou subtração eu considerei que você colocaria os maiores números
na esquerda. Claro, se essa for a conta que você queira fazer. Só to fazendo essa 
observação porque, na hora da divisão, caso o divisor seja 0 ele tem que estar na direita.
Caso, contrário ele vai fazer a divisão e dependendo do que você queira pode dar um
resultado errado.
Ah! eu fiz também um analizador de expressão, mas ele está comentado no código. Você disse
que as expressões estariam certas, mas eu fiz uma funçãozinha para checar. Ela checa se os
parênteses estão bem colocados e se há caracteres que não sejam operações ou números.
Acho que isso é tudo, tudo o que eu fiz ta comentado no código caso haja alguma dúvida. Eu 
comentei até o makefile.
Eu vou mandar também um "expressões.txt" que foram as expressões que eu usei. Elas estão
com os resultados do lado dela.